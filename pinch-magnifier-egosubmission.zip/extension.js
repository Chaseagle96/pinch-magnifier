import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

import {MIN_ZOOM, zoomForScaleDelta} from './zoom.js';

const APPLICATIONS_SCHEMA = 'org.gnome.desktop.a11y.applications';
const MAGNIFIER_SCHEMA = 'org.gnome.desktop.a11y.magnifier';
const INTERFACE_SCHEMA = 'org.gnome.desktop.interface';
const BORROWED_TRACKING_KEY = 'borrowed-mouse-tracking';
const ENABLED_KEY = 'screen-magnifier-enabled';
const FACTOR_KEY = 'mag-factor';
const RESET_KEY = 'reset-shortcut';
const TOGGLE_KEY = 'toggle-shortcut';
const GLOBAL_LEFT_ALT_KEY = 'global-left-alt-shortcut';
const GLOBAL_FN_KEY = 'global-fn-shortcut';
const GLOBAL_RIGHT_ALT_KEY = 'global-right-alt-shortcut';
const GLOBAL_RIGHT_ALT_ZOOM_OUT_KEY = 'global-right-alt-zoom-out-shortcut';
const GLOBAL_RIGHT_ALT_ZOOM_IN_KEY = 'global-right-alt-zoom-in-shortcut';
const GLOBAL_RIGHT_CTRL_KEY = 'global-right-ctrl-shortcut';
const LEFT_ALT_SHORTCUT = '<Alt>';
const FN_SHORTCUT = 'Fn';
const PREVIOUS_ZOOM_KEY = 'previous-zoom';
const LENS_ZOOM_KEY = 'lens-zoom';
const PINCH_ACTION_MODES = Shell.ActionMode.ALL ?? -1;
const NON_MASKABLE_KEY_FLAG = Meta.KeyBindingFlags.NON_MASKABLE ?? 0;
const TRACKING_VALUES = ['none', 'centered', 'proportional', 'push'];
const TRACKING_CYCLE = ['proportional', 'centered', 'push'];
const GLOBAL_KEYBINDINGS = [
    [GLOBAL_LEFT_ALT_KEY, Clutter.KEY_Alt_L],
    [GLOBAL_FN_KEY, Clutter.KEY_Fn],
    [GLOBAL_RIGHT_ALT_KEY, Clutter.KEY_Alt_R],
    [GLOBAL_RIGHT_CTRL_KEY, Clutter.KEY_Control_R],
];
const RIGHT_ALT_ZOOM_KEYBINDINGS = [
    [GLOBAL_RIGHT_ALT_ZOOM_OUT_KEY, -1],
    [GLOBAL_RIGHT_ALT_ZOOM_IN_KEY, 1],
];
const FINGERS = 3;
const SNAP_AT = 1.03;
const CHANGE_EPSILON = 0.0005;
const ACTIVE_EPSILON = 0.001;
const LOG_SETTLE_EPSILON = 0.0005;
const MAX_FRAME_MS = 50;
const RELEASE_SETTLE_MS = 50;
const RELEASE_TAU_MS = 12;
const WATCHDOG_MS = 3000;
const WATCHDOG_POLL_MS = 250;
const HOLD_ACTIVATION_MS = 150;
const SHORTCUT_ZOOM_MS = 180;
const KEYBOARD_ZOOM_RATIO = 1.25;
const LENS_ANIMATION_MS = 180;
const LENS_FOLLOW_MS = 16;
const LENS_WIDTH = 360;
const LENS_HEIGHT = 240;
const VIEWPORT_UNLOCK_MS = 120;
const MODIFIER_RELEASE_POLL_MS = 16;
const ALT_MODIFIER_MASK = Clutter.ModifierType?.MOD1_MASK ?? 8;
const CONTROL_MODIFIER_MASK = Clutter.ModifierType?.CONTROL_MASK ?? 4;

const newToggleShortcutState = () => ({
    holdId: 0,
    down: false,
    holdActivated: false,
    wasActive: false,
    temporary: false,
    usedWithOtherKey: false,
});

export default class PinchMagnifier extends Extension {
    enable() {
        this._settings = this.getSettings();
        if (this._settings.get_strv(GLOBAL_LEFT_ALT_KEY)?.[0] === '<Alt>')
            this._settings.set_strv(GLOBAL_LEFT_ALT_KEY, ['Alt_L']);
        this._apps = new Gio.Settings({schema_id: APPLICATIONS_SCHEMA});
        this._magnifier = new Gio.Settings({schema_id: MAGNIFIER_SCHEMA});
        this._interface = new Gio.Settings({schema_id: INTERFACE_SCHEMA});
        this._gesture = false;
        this._settling = false;
        this._gestureGrab = null;
        this._ignoreUntilBegin = false;
        this._frameId = 0;
        this._frameSerial = 0;
        this._lastFrameTimeUs = 0;
        this._lastInputTimeUs = 0;
        this._lastPinchAtUs = 0;
        this._inputSpeed = 0;
        this._visualFactor = MIN_ZOOM;
        this._shortcutAnimating = false;
        this._shortcutAnimationStartUs = 0;
        this._shortcutAnimationStartFactor = MIN_ZOOM;
        this._shortcutAnimationDurationUs = 0;
        this._gestureAnchor = null;
        this._settleDeadlineUs = 0;
        this._hideId = 0;
        this._watchdogId = 0;
        this._indicatorAllocationId = 0;
        this._monitorsId = 0;
        this._gestureTracking = null;
        this._toggleShortcutState = newToggleShortcutState();
        this._rightAltShortcutState = newToggleShortcutState();
        this._leftAltDown = false;
        this._leftAltUsedWithOtherKey = false;
        this._fnDown = false;
        this._fnUsedWithOtherKey = false;
        this._fnWasActive = false;
        this._fnDirectionalUsed = false;
        this._fnPointerOrigin = null;
        this._fnAxis = null;
        this._fnWasLocked = false;
        this._fnWarping = false;
        this._rightAltDown = false;
        this._rightCtrlDown = false;
        this._rightCtrlUsedWithOtherKey = false;
        this._rightCtrlHoldId = 0;
        this._rightCtrlHoldActivated = false;
        this._rightCtrlWasActive = false;
        this._rightCtrlTemporary = false;
        this._modifierReleaseWatchId = 0;
        this._trackingCycleCombo = false;
        this._lensActive = false;
        this._lensRegionState = null;
        this._lensWasActive = false;
        this._lensWasEnabled = false;
        this._lensFrame = null;
        this._lensFollowId = 0;
        this._viewportLocked = false;
        this._viewportUnlocking = false;
        this._viewportUnlockId = 0;
        this._trackingChanging = false;
        this._trackingChangeId = 0;
        this._trackingChangeTracking = null;
        this._lockedTracking = null;
        this._toggleKeybindingRegistered = false;
        this._globalKeybindingsRegistered = new Set();

        this._restoreInterruptedTracking();
        this._savedMouseTracking = this._magnifier.get_string('mouse-tracking');
        this._writeTrackingRecovery();
        this._readSettings();
        this._active = this._actualActive();
        this._applyTracking();
        this._createIndicator();

        this._settingsId = this._settings.connect('changed', (_s, key) => {
            this._readSettings();
            if (key === 'maximum-zoom' && !this._gesture && !this._settling &&
                this._actualActive() && this._liveFactor() > this._maximum)
                this._magnifier.set_double(FACTOR_KEY, this._maximum);
            if (key === 'mouse-tracking')
                this._applyTracking();
            if (key === 'show-indicator' && !this._showIndicator)
                this._hideIndicator();
            if (key === TOGGLE_KEY ||
                key === GLOBAL_LEFT_ALT_KEY ||
                key === GLOBAL_FN_KEY ||
                key === GLOBAL_RIGHT_ALT_KEY ||
                key === GLOBAL_RIGHT_ALT_ZOOM_OUT_KEY ||
                key === GLOBAL_RIGHT_ALT_ZOOM_IN_KEY ||
                key === GLOBAL_RIGHT_CTRL_KEY)
                this._registerShortcutBindings();
        });

        this._appsId = this._apps.connect(`changed::${ENABLED_KEY}`, () => {
            this._active = this._actualActive();
            if (!this._active && this._lensActive)
                this._setLensMode(false);
        });

        this._factorId = this._magnifier.connect(`changed::${FACTOR_KEY}`, () => {
            const factor = this._magnifier.get_double(FACTOR_KEY);
            if (this._lensActive)
                this._rememberLensZoom(factor);
            if (!this._gesture && this._actualActive())
                this._rememberZoom(factor);
        });
        this._eventId = global.stage.connect(
            'captured-event',
            (_actor, event) => this._handleEvent(event)
        );

        Main.wm.addKeybinding(
            RESET_KEY,
            this._settings,
            NON_MASKABLE_KEY_FLAG,
            PINCH_ACTION_MODES,
            () => this._reset()
        );

        this._registerShortcutBindings();
    }

    disable() {
        try {
            this._endFnDirectionalFollow();
            this._cancelTrackingChange();
            this._cancelViewportUnlock();
            const temporaryToggle = this._toggleShortcutState.temporary ||
                this._rightAltShortcutState.temporary;
            this._cancelToggleShortcut(false);
            this._cancelToggleShortcut(false, this._rightAltShortcutState);
            this._cancelLensShortcut(true);
            this._clearModifierReleaseWatch();
            this._setLensMode(false);
            if (temporaryToggle)
                this._reset();
            else if (this._gesture)
                this._cancel();
            else if (this._settling)
                this._interruptSettling();
        } catch (error) {
            this._logError('Could not restore state while disabling', error);
            this._cancelFrame();
            this._disarmWatchdog();
            this._gesture = false;
            this._settling = false;
            this._gestureAnchor = null;
            this._releaseGestureGrab();
        }

        this._leftAltDown = false;
        this._leftAltUsedWithOtherKey = false;
        this._fnDown = false;
        this._fnUsedWithOtherKey = false;
        this._fnWasActive = false;
        this._fnDirectionalUsed = false;
        this._fnPointerOrigin = null;
        this._fnAxis = null;
        this._fnWasLocked = false;
        this._fnWarping = false;
        this._rightAltDown = false;
        this._rightCtrlDown = false;
        this._rightCtrlUsedWithOtherKey = false;
        this._rightCtrlHoldId = 0;
        this._rightCtrlHoldActivated = false;
        this._rightCtrlWasActive = false;
        this._rightCtrlTemporary = false;
        this._trackingCycleCombo = false;
        this._lensActive = false;
        this._lensRegionState = null;
        this._lensWasActive = false;
        this._lensWasEnabled = false;
        this._lensFollowId = 0;
        this._shortcutAnimating = false;
        this._shortcutAnimationStartUs = 0;
        this._shortcutAnimationStartFactor = MIN_ZOOM;
        this._shortcutAnimationDurationUs = 0;

        this._cancelFrame();
        this._disarmWatchdog();
        if (this._eventId)
            global.stage.disconnect(this._eventId);
        if (this._settingsId)
            this._settings.disconnect(this._settingsId);
        if (this._appsId)
            this._apps.disconnect(this._appsId);
        if (this._factorId)
            this._magnifier.disconnect(this._factorId);
        Main.wm.removeKeybinding(RESET_KEY);
        this._removeGlobalKeybindings();
        if (this._toggleKeybindingRegistered)
            Main.wm.removeKeybinding(TOGGLE_KEY);
        try {
            this._restoreGestureTracking();
            this._restoreSavedMouseTracking();
        } catch (error) {
            this._logError('Could not restore native mouse tracking', error);
        }
        this._resumePointerTracking();
        this._releaseGestureGrab();
        this._cancelHide();
        if (this._monitorsId)
            Main.layoutManager.disconnect(this._monitorsId);
        if (this._indicatorAllocationId)
            this._indicator?.disconnect(this._indicatorAllocationId);
        this._indicator?.destroy();

        this._eventId = 0;
        this._settingsId = 0;
        this._appsId = 0;
        this._factorId = 0;
        this._toggleKeybindingRegistered = false;
        this._watchdogId = 0;
        this._monitorsId = 0;
        this._indicatorAllocationId = 0;
        this._indicator = null;
        this._lensFrame?.destroy();
        this._lensFrame = null;
        this._gestureGrab = null;
        this._savedMouseTracking = null;
        this._gestureTracking = null;
        this._settings = null;
        this._apps = null;
        this._magnifier = null;
        this._interface = null;
    }

    _readSettings() {
        this._sensitivity = this._settings.get_double('sensitivity');
        this._maximum = this._settings.get_double('maximum-zoom');
        this._tracking = this._settings.get_string('mouse-tracking');
        this._inverted = this._settings.get_boolean('invert-direction');
        this._smoothingMs = this._settings.get_double('smoothing-ms');
        this._showIndicator = this._settings.get_boolean('show-indicator');
        this._previousZoom = Math.min(
            this._maximum,
            Math.max(MIN_ZOOM, this._settings.get_double(PREVIOUS_ZOOM_KEY))
        );

        if (Number.isFinite(this._target))
            this._target = Math.min(this._maximum, Math.max(MIN_ZOOM, this._target));
    }

    _shortcutValue(key) {
        const [accelerator] = this._settings?.get_strv(key) ?? [];
        if (!accelerator || accelerator === 'disabled')
            return null;
        if (key === GLOBAL_LEFT_ALT_KEY && accelerator === LEFT_ALT_SHORTCUT)
            return 'Alt_L';
        return accelerator;
    }

    _toggleShortcutIsReserved(accelerator) {
        return accelerator === LEFT_ALT_SHORTCUT ||
            accelerator === 'Alt_L' ||
            accelerator === 'Alt_R' ||
            accelerator === 'Control_R' ||
            accelerator === FN_SHORTCUT;
    }

    _registerShortcutBindings() {
        this._removeGlobalKeybindings();
        if (this._toggleKeybindingRegistered) {
            Main.wm.removeKeybinding(TOGGLE_KEY);
            this._toggleKeybindingRegistered = false;
        }

        const flags = Meta.KeyBindingFlags.IGNORE_AUTOREPEAT |
            Meta.KeyBindingFlags.TRIGGER_RELEASE |
            NON_MASKABLE_KEY_FLAG;
        for (const [key, symbol] of GLOBAL_KEYBINDINGS) {
            const accelerator = this._shortcutValue(key);
            if (!accelerator)
                continue;

            Main.wm.addKeybinding(
                key,
                this._settings,
                flags,
                PINCH_ACTION_MODES,
                (_display, _window, event) => this._handleGlobalKeybinding(symbol, event)
            );
            this._globalKeybindingsRegistered.add(key);
        }

        const zoomFlags = NON_MASKABLE_KEY_FLAG;
        for (const [key, direction] of RIGHT_ALT_ZOOM_KEYBINDINGS) {
            if (!this._shortcutValue(key))
                continue;

            Main.wm.addKeybinding(
                key,
                this._settings,
                zoomFlags,
                PINCH_ACTION_MODES,
                () => this._handleRightAltZoomBinding(direction)
            );
            this._globalKeybindingsRegistered.add(key);
        }

        const accelerator = this._shortcutValue(TOGGLE_KEY);
        if (accelerator && !this._toggleShortcutIsReserved(accelerator)) {
            Main.wm.addKeybinding(
                TOGGLE_KEY,
                this._settings,
                flags,
                PINCH_ACTION_MODES,
                (_display, _window, event) => this._handleToggleShortcut(event)
            );
            this._toggleKeybindingRegistered = true;
        }
    }

    _removeGlobalKeybindings() {
        for (const key of this._globalKeybindingsRegistered)
            Main.wm.removeKeybinding(key);
        this._globalKeybindingsRegistered.clear();
    }

    _applyTracking() {
        const suspended = this._gesture || this._settling ||
            this._viewportLocked || this._viewportUnlocking ||
            this._trackingChanging;
        const tracking = this._lensActive ? 'centered' : this._tracking;
        this._magnifier.set_string('mouse-tracking', suspended ? 'none' : tracking);
        if (suspended) {
            this._magnifier.set_string('focus-tracking', 'none');
            this._magnifier.set_string('caret-tracking', 'none');
        }
    }

    _writeTrackingRecovery() {
        this._settings.set_string(BORROWED_TRACKING_KEY, JSON.stringify({
            mouse: this._savedMouseTracking ?? '',
            focus: this._gestureTracking?.focus ?? '',
            caret: this._gestureTracking?.caret ?? '',
        }));
    }

    _restoreInterruptedTracking() {
        const raw = this._settings.get_string(BORROWED_TRACKING_KEY);
        if (!raw)
            return;

        let saved;
        try {
            saved = JSON.parse(raw);
        } catch (_error) {
            // Recover the plain value written by the first ownership pass.
            saved = {mouse: raw};
        }

        try {
            for (const [property, key] of [
                ['mouse', 'mouse-tracking'],
                ['focus', 'focus-tracking'],
                ['caret', 'caret-tracking'],
            ]) {
                if (TRACKING_VALUES.includes(saved?.[property]))
                    this._magnifier.set_string(key, saved[property]);
            }
            this._settings.set_string(BORROWED_TRACKING_KEY, '');
        } catch (error) {
            this._logError('Could not recover borrowed mouse tracking', error);
        }
    }

    _restoreSavedMouseTracking() {
        if (!this._savedMouseTracking)
            return;

        this._magnifier.set_string('mouse-tracking', this._savedMouseTracking);
        if (this._gestureTracking)
            this._writeTrackingRecovery();
        else
            this._settings.set_string(BORROWED_TRACKING_KEY, '');
        this._savedMouseTracking = null;
    }

    _restoreGestureTracking() {
        const tracking = this._gestureTracking;
        if (!tracking)
            return;

        let restored = true;
        for (const [key, value] of [
            ['focus-tracking', tracking.focus],
            ['caret-tracking', tracking.caret],
        ]) {
            try {
                this._magnifier.set_string(key, value);
            } catch (error) {
                restored = false;
                this._logError(`Could not restore ${key}`, error);
            }
        }

        if (restored) {
            this._gestureTracking = null;
            try {
                this._writeTrackingRecovery();
            } catch (error) {
                this._logError('Could not update tracking recovery state', error);
            }
        }
    }

    _handleEvent(event) {
        const type = this._eventType(event);
        if (this._lensActive && type === Clutter.EventType.MOTION)
            this._positionLensFrame();

        const shortcutAllowed = typeof Main.actionMode !== 'number' ||
            PINCH_ACTION_MODES < 0 || (Main.actionMode & PINCH_ACTION_MODES);
        if (shortcutAllowed) {
            const shortcutResult = this._handleShortcutEvent(event);
            if (shortcutResult !== null)
                return shortcutResult;
        }

        if (type !== Clutter.EventType.TOUCHPAD_PINCH)
            return Clutter.EVENT_PROPAGATE;

        if (typeof Main.actionMode === 'number' && PINCH_ACTION_MODES >= 0 &&
            !(Main.actionMode & PINCH_ACTION_MODES)) {
            try {
                if (this._gesture)
                    this._cancel();
                else if (this._settling)
                    this._interruptSettling();
            } catch (error) {
                this._logError('Could not stop pinch outside an allowed action mode', error);
            }
            return Clutter.EVENT_PROPAGATE;
        }

        const phase = event.get_gesture_phase();

        if (phase === Clutter.TouchpadGesturePhase.BEGIN) {
            this._ignoreUntilBegin = false;

            if (this._fingerCount(event) !== FINGERS)
                return Clutter.EVENT_PROPAGATE;

            if (this._settling) {
                try {
                    this._interruptSettling();
                } catch (error) {
                    this._logError('Could not stop the previous zoom settle', error);
                    this._settling = false;
                    this._settleDeadlineUs = 0;
                    this._restoreGestureTracking();
                    this._applyTracking();
                    this._resumePointerTracking();
                }
            }

            if (this._gesture) {
                try {
                    this._cancel();
                } catch (error) {
                    this._logError('Could not cancel stale pinch gesture', error);
                }
            }

            if (!this._claimGesture())
                return Clutter.EVENT_PROPAGATE;

            try {
                this._begin();
            } catch (error) {
                this._logError('Could not begin three-finger pinch', error);
                if (this._gesture)
                    this._handleGestureFailure(error);
                else {
                    this._cancelFrame();
                    this._disarmWatchdog();
                    this._gesture = false;
                    this._ignoreUntilBegin = true;
                    this._releaseGestureGrab();
                }
            }

            return Clutter.EVENT_STOP;
        }

        if (this._ignoreUntilBegin)
            return Clutter.EVENT_STOP;

        if (!this._gesture)
            return Clutter.EVENT_PROPAGATE;

        try {
            if (phase === Clutter.TouchpadGesturePhase.UPDATE)
                this._update(event);
            else if (phase === Clutter.TouchpadGesturePhase.END)
                this._finish();
            else if (phase === Clutter.TouchpadGesturePhase.CANCEL)
                this._cancel();
        } catch (error) {
            this._handleGestureFailure(error);
        }

        return Clutter.EVENT_STOP;
    }

    _handleShortcutEvent(event) {
        const rightAltResult = this._handleRightAltEvent(event);
        const rightCtrlResult = this._handleRightCtrlEvent(event);
        const leftAltResult = this._handleLeftAltEvent(event);
        const fnResult = this._handleFnEvent(event);
        this._updateModifierReleaseWatch();
        if (rightAltResult === Clutter.EVENT_STOP ||
            rightCtrlResult === Clutter.EVENT_STOP ||
            leftAltResult === Clutter.EVENT_STOP ||
            fnResult === Clutter.EVENT_STOP)
            return Clutter.EVENT_STOP;
        if (rightAltResult !== null || rightCtrlResult !== null ||
            leftAltResult !== null || fnResult !== null)
            return Clutter.EVENT_PROPAGATE;
        return null;
    }

    _handleGlobalKeybinding(symbol, event) {
        const type = this._eventType(event);
        if (type !== Clutter.EventType.KEY_PRESS &&
            type !== Clutter.EventType.KEY_RELEASE)
            return;

        if (type === Clutter.EventType.KEY_PRESS &&
            this._recoverStaleModifier(symbol))
            return;

        this._handleShortcutEvent({
            type: () => type,
            get_key_symbol: () => symbol,
        });
    }

    _recoverStaleModifier(symbol) {
        if (symbol === Clutter.KEY_Alt_L && this._leftAltDown) {
            const temporary = this._toggleShortcutState.temporary;
            this._cancelToggleShortcut(true);
            this._leftAltDown = false;
            this._leftAltUsedWithOtherKey = false;
            return temporary;
        }

        if (symbol === Clutter.KEY_Alt_R && this._rightAltDown) {
            const temporary = this._rightAltShortcutState.temporary;
            this._cancelToggleShortcut(true, this._rightAltShortcutState);
            this._rightAltDown = false;
            return temporary;
        }

        if (symbol === Clutter.KEY_Control_R && this._rightCtrlDown) {
            const temporary = this._rightCtrlTemporary;
            this._cancelLensShortcut(true);
            return temporary;
        }

        if (symbol === Clutter.KEY_Fn && this._fnDown)
            this._handleShortcutEvent(this._shortcutKeyEvent(
                Clutter.EventType.KEY_RELEASE,
                Clutter.KEY_Fn
            ));

        return false;
    }

    _eventType(event) {
        return event.type?.() ?? event.get_type?.();
    }

    _leftAltShortcutEnabled() {
        const [accelerator] = this._settings?.get_strv(TOGGLE_KEY) ?? [];
        return accelerator === LEFT_ALT_SHORTCUT;
    }

    _fnShortcutEnabled() {
        const [accelerator] = this._settings?.get_strv(TOGGLE_KEY) ?? [];
        return accelerator === FN_SHORTCUT;
    }

    _handleRightAltEvent(event) {
        const type = this._eventType(event);
        if (type !== Clutter.EventType.KEY_PRESS &&
            type !== Clutter.EventType.KEY_RELEASE)
            return null;

        const symbol = event.get_key_symbol?.();
        const state = this._rightAltShortcutState;
        const enabled = this._leftAltShortcutEnabled();
        const zoomDirection = this._rightAltZoomDirection(event);
        if (type === Clutter.EventType.KEY_PRESS) {
            if (symbol !== Clutter.KEY_Alt_R) {
                if (this._rightAltDown) {
                    if (symbol === Clutter.KEY_Shift_L ||
                        symbol === Clutter.KEY_Shift_R)
                        return Clutter.EVENT_PROPAGATE;
                    if (enabled && zoomDirection) {
                        state.usedWithOtherKey = true;
                        this._cancelToggleShortcut(false, state);
                        return Clutter.EVENT_PROPAGATE;
                    }
                    state.usedWithOtherKey = true;
                    if (enabled)
                        this._cancelToggleShortcut(true, state);
                }
                return this._rightAltDown ? Clutter.EVENT_PROPAGATE : null;
            }

            if (this._rightAltDown)
                return Clutter.EVENT_PROPAGATE;

            this._rightAltDown = true;
            state.usedWithOtherKey = false;
            if (enabled) {
                this._handleToggleShortcut(event, state);
                if (this._leftAltDown || this._fnDown || this._rightCtrlDown) {
                    state.usedWithOtherKey = true;
                    this._cancelToggleShortcut(true, state);
                }
            }
            return Clutter.EVENT_PROPAGATE;
        }

        if (!this._rightAltDown)
            return null;
        if (zoomDirection)
            return Clutter.EVENT_STOP;
        if (symbol !== Clutter.KEY_Alt_R)
            return Clutter.EVENT_PROPAGATE;

        this._rightAltDown = false;
        const usedWithOtherKey = state.usedWithOtherKey;
        state.usedWithOtherKey = false;
        if (!enabled)
            this._cancelToggleShortcut(false, state);
        else if (usedWithOtherKey)
            this._cancelToggleShortcut(true, state);
        else
            this._handleToggleShortcut(event, state);
        return Clutter.EVENT_STOP;
    }

    _rightAltZoomDirection(event) {
        const symbol = event.get_key_symbol?.();
        if (symbol !== undefined) {
            if (symbol === Clutter.KEY_less)
                return -1;
            if (symbol === Clutter.KEY_greater)
                return 1;
        }

        const shifted = event.has_shift_modifier?.() ??
            Boolean(event.get_state?.() & (Clutter.ModifierType?.SHIFT_MASK ?? 1));
        if (shifted) {
            if (symbol === Clutter.KEY_comma)
                return -1;
            if (symbol === Clutter.KEY_period)
                return 1;
        }

        const unicode = event.get_key_unicode?.();
        return unicode === '<'.codePointAt(0) ? -1 :
            unicode === '>'.codePointAt(0) ? 1 : 0;
    }

    _handleRightAltZoomBinding(direction) {
        if (!this._rightAltDown)
            return;

        this._cancelToggleShortcut(false, this._rightAltShortcutState);
        this._stepShortcutZoom(direction);
    }

    _stepShortcutZoom(direction) {
        const current = this._shortcutAnimating
            ? this._target
            : this._currentFactor();
        const scaled = direction > 0
            ? current * KEYBOARD_ZOOM_RATIO
            : current / KEYBOARD_ZOOM_RATIO;
        const next = Number(Math.min(
            this._maximum,
            Math.max(MIN_ZOOM, scaled)
        ).toFixed(2));
        if (Math.abs(next - current) < CHANGE_EPSILON)
            return;

        this._startShortcutZoom(next);
    }

    _handleRightCtrlEvent(event) {
        const type = this._eventType(event);
        if (type !== Clutter.EventType.KEY_PRESS &&
            type !== Clutter.EventType.KEY_RELEASE)
            return null;

        const symbol = event.get_key_symbol?.();
        if (type === Clutter.EventType.KEY_PRESS) {
            if (symbol !== Clutter.KEY_Control_R) {
                if (this._rightCtrlDown)
                    this._rightCtrlUsedWithOtherKey = true;
                return this._rightCtrlDown ? Clutter.EVENT_PROPAGATE : null;
            }

            if (this._rightCtrlDown)
                return Clutter.EVENT_PROPAGATE;

            this._rightCtrlDown = true;
            this._rightCtrlUsedWithOtherKey = false;
            this._rightCtrlWasActive = this._lensActive;
            this._rightCtrlHoldActivated = false;
            this._rightCtrlTemporary = false;
            this._rightCtrlHoldId = GLib.timeout_add(
                GLib.PRIORITY_DEFAULT,
                HOLD_ACTIVATION_MS,
                () => {
                    this._rightCtrlHoldId = 0;
                    if (!this._rightCtrlDown)
                        return GLib.SOURCE_REMOVE;

                    this._rightCtrlHoldActivated = true;
                    if (!this._rightCtrlWasActive) {
                        this._setLensMode(true);
                        this._rightCtrlTemporary = this._lensActive;
                    }
                    return GLib.SOURCE_REMOVE;
                }
            );
            return Clutter.EVENT_PROPAGATE;
        }

        if (!this._rightCtrlDown)
            return null;
        if (symbol !== Clutter.KEY_Control_R)
            return Clutter.EVENT_PROPAGATE;

        const usedWithOtherKey = this._rightCtrlUsedWithOtherKey;
        const held = this._rightCtrlHoldActivated;
        const temporary = this._rightCtrlTemporary;
        this._rightCtrlDown = false;
        this._rightCtrlUsedWithOtherKey = false;
        this._rightCtrlHoldActivated = false;
        this._rightCtrlWasActive = false;
        this._rightCtrlTemporary = false;
        this._clearLensHold();

        if ((usedWithOtherKey || held) && temporary)
            this._setLensMode(false);
        else if (!usedWithOtherKey && !held)
            this._toggleLensMode();
        return Clutter.EVENT_STOP;
    }

    _handleLeftAltEvent(event) {
        const type = this._eventType(event);
        if (type !== Clutter.EventType.KEY_PRESS &&
            type !== Clutter.EventType.KEY_RELEASE)
            return null;

        const symbol = event.get_key_symbol?.();
        const enabled = this._leftAltShortcutEnabled();
        if (type === Clutter.EventType.KEY_PRESS) {
            if (symbol === Clutter.KEY_Alt_L) {
                if (this._leftAltDown)
                    return Clutter.EVENT_PROPAGATE;

                this._leftAltDown = true;
                this._leftAltUsedWithOtherKey = false;
                if (this._rightAltDown || this._rightCtrlDown) {
                    this._leftAltUsedWithOtherKey = true;
                } else if (this._fnDown) {
                    if (!this._fnUsedWithOtherKey)
                        this._beginTrackingCycleCombo();
                    else
                        this._leftAltUsedWithOtherKey = true;
                } else if (enabled) {
                    this._handleToggleShortcut(event);
                }
                return Clutter.EVENT_PROPAGATE;
            }

            if (!this._leftAltDown)
                return null;

            if (symbol === Clutter.KEY_Fn) {
                if (!this._leftAltUsedWithOtherKey &&
                    !this._fnUsedWithOtherKey)
                    this._beginTrackingCycleCombo();
                else
                    this._leftAltUsedWithOtherKey = true;
                return Clutter.EVENT_PROPAGATE;
            }

            if (!this._trackingCycleCombo) {
                this._leftAltUsedWithOtherKey = true;
                if (enabled)
                    this._cancelToggleShortcut(true);
            }
            return Clutter.EVENT_PROPAGATE;
        }

        if (!this._leftAltDown)
            return null;

        if (symbol !== Clutter.KEY_Alt_L) {
            if (this._trackingCycleCombo && symbol === Clutter.KEY_Fn)
                return Clutter.EVENT_STOP;
            return Clutter.EVENT_PROPAGATE;
        }

        this._leftAltDown = false;
        if (this._trackingCycleCombo) {
            this._leftAltUsedWithOtherKey = false;
            this._finishTrackingCycleCombo();
            return Clutter.EVENT_STOP;
        }

        const usedWithOtherKey = this._leftAltUsedWithOtherKey;
        this._leftAltUsedWithOtherKey = false;
        if (!enabled)
            return Clutter.EVENT_PROPAGATE;

        if (usedWithOtherKey)
            this._cancelToggleShortcut(true);
        else
            this._handleToggleShortcut(event);
        return Clutter.EVENT_STOP;
    }

    _handleFnEvent(event) {
        const type = this._eventType(event);
        if (type === Clutter.EventType.MOTION)
            return this._handleFnMotion(event);

        if (type !== Clutter.EventType.KEY_PRESS &&
            type !== Clutter.EventType.KEY_RELEASE)
            return null;

        const symbol = event.get_key_symbol?.();
        if (type === Clutter.EventType.KEY_PRESS) {
            if (symbol === Clutter.KEY_Fn) {
                if (this._fnDown)
                    return Clutter.EVENT_PROPAGATE;

                this._fnDown = true;
                this._fnUsedWithOtherKey = false;
                this._fnWasActive = this._currentFactor() > MIN_ZOOM + ACTIVE_EPSILON;
                const [x, y] = global.get_pointer();
                this._fnPointerOrigin = Number.isFinite(x) && Number.isFinite(y)
                    ? [x, y]
                    : null;
                this._fnAxis = null;
                this._fnDirectionalUsed = false;
                this._fnWasLocked = false;
                if (this._leftAltDown) {
                    if (!this._leftAltUsedWithOtherKey)
                        this._beginTrackingCycleCombo();
                    else
                        this._fnUsedWithOtherKey = true;
                }
                return Clutter.EVENT_PROPAGATE;
            }

            if (this._fnDown) {
                if (symbol === Clutter.KEY_Alt_L) {
                    if (!this._leftAltUsedWithOtherKey &&
                        !this._fnUsedWithOtherKey)
                        this._beginTrackingCycleCombo();
                    else
                        this._fnUsedWithOtherKey = true;
                } else if (!this._trackingCycleCombo) {
                    this._fnUsedWithOtherKey = true;
                }
                return Clutter.EVENT_PROPAGATE;
            }
            return null;
        }

        if (!this._fnDown)
            return null;

        if (symbol !== Clutter.KEY_Fn) {
            if (this._trackingCycleCombo && symbol === Clutter.KEY_Alt_L)
                return Clutter.EVENT_STOP;
            return Clutter.EVENT_PROPAGATE;
        }

        const usedWithOtherKey = this._fnUsedWithOtherKey;
        const wasActive = this._fnWasActive;
        const directional = this._fnDirectionalUsed;
        this._fnDown = false;
        this._fnUsedWithOtherKey = false;
        this._fnWasActive = false;
        this._endFnDirectionalFollow();
        if (this._trackingCycleCombo) {
            this._finishTrackingCycleCombo();
        } else if (!usedWithOtherKey && wasActive && !directional) {
            if (this._viewportLocked)
                this._unlockViewport();
            else
                this._lockViewport();
        }
        return Clutter.EVENT_STOP;
    }

    _handleFnMotion(event) {
        if (!this._fnDown || this._trackingCycleCombo)
            return this._fnDown ? Clutter.EVENT_PROPAGATE : null;
        if (this._fnWarping)
            return Clutter.EVENT_PROPAGATE;

        const coords = event.get_coords?.();
        if (!Array.isArray(coords) || coords.length < 2 ||
            !Number.isFinite(coords[0]) || !Number.isFinite(coords[1]))
            return Clutter.EVENT_PROPAGATE;

        const [x, y] = coords;
        if (!this._fnPointerOrigin)
            this._fnPointerOrigin = [x, y];

        const [originX, originY] = this._fnPointerOrigin;
        const dx = x - originX;
        const dy = y - originY;
        if (dx === 0 && dy === 0)
            return Clutter.EVENT_PROPAGATE;

        this._fnAxis ??= Math.abs(dx) >= Math.abs(dy) ? 'horizontal' : 'vertical';
        const constrainedX = this._fnAxis === 'horizontal' ? x : originX;
        const constrainedY = this._fnAxis === 'vertical' ? y : originY;
        const needsWarp = Math.abs(constrainedX - x) >= 0.5 ||
            Math.abs(constrainedY - y) >= 0.5;

        this._fnDirectionalUsed = true;
        if (this._viewportLocked && !this._viewportUnlocking && !this._fnWasLocked) {
            this._fnWasLocked = true;
            this._viewportLocked = false;
            this._applyTracking();
            this._resumePointerTracking();
        }

        if (!needsWarp)
            return Clutter.EVENT_PROPAGATE;

        if (!this._warpPointer(constrainedX, constrainedY))
            return Clutter.EVENT_PROPAGATE;

        return Clutter.EVENT_STOP;
    }

    _warpPointer(x, y) {
        try {
            const backend = global.stage.get_context?.()?.get_backend?.();
            const seat = backend?.get_default_seat?.() ??
                Clutter.get_default_backend?.()?.get_default_seat?.();
            if (!seat?.warp_pointer)
                return false;

            this._fnWarping = true;
            seat.warp_pointer(Math.round(x), Math.round(y));
            return true;
        } catch (error) {
            this._logError('Could not constrain pointer movement', error);
            return false;
        } finally {
            this._fnWarping = false;
        }
    }

    _endFnDirectionalFollow() {
        if (this._fnWasLocked && !this._viewportLocked) {
            this._viewportLocked = true;
            const region = this._region();
            region?._clearScrollContentsTimer?.();
            if (region && '_followingCursor' in region)
                region._followingCursor = false;
            this._applyTracking();
        }

        this._fnDirectionalUsed = false;
        this._fnPointerOrigin = null;
        this._fnAxis = null;
        this._fnWasLocked = false;
    }

    _toggleLensMode() {
        return this._setLensMode(!this._lensActive);
    }

    _lensViewportSize() {
        const screenWidth = Number.isFinite(global.screen_width)
            ? Math.max(1, global.screen_width)
            : LENS_WIDTH;
        const screenHeight = Number.isFinite(global.screen_height)
            ? Math.max(1, global.screen_height)
            : LENS_HEIGHT;
        return {
            width: Math.min(LENS_WIDTH, screenWidth),
            height: Math.min(LENS_HEIGHT, screenHeight),
        };
    }

    _lensViewportRect() {
        const {width, height} = this._lensViewportSize();
        const [pointerX, pointerY] = global.get_pointer();
        const xPointer = Number.isFinite(pointerX) ? pointerX : width / 2;
        const yPointer = Number.isFinite(pointerY) ? pointerY : height / 2;
        const screenWidth = Number.isFinite(global.screen_width)
            ? Math.max(width, global.screen_width)
            : width;
        const screenHeight = Number.isFinite(global.screen_height)
            ? Math.max(height, global.screen_height)
            : height;

        return {
            x: Math.round(Math.max(0, Math.min(screenWidth - width, xPointer - width / 2))),
            y: Math.round(Math.max(0, Math.min(screenHeight - height, yPointer - height / 2))),
            width,
            height,
        };
    }

    _captureLensRegionState(region) {
        const viewportValues = [
            region._viewPortX,
            region._viewPortY,
            region._viewPortWidth,
            region._viewPortHeight,
        ];
        const viewport = viewportValues.every(Number.isFinite)
            ? {
                x: viewportValues[0],
                y: viewportValues[1],
                width: viewportValues[2],
                height: viewportValues[3],
            }
            : {
                x: 0,
                y: 0,
                width: Number.isFinite(global.screen_width)
                    ? Math.max(1, global.screen_width)
                    : LENS_WIDTH,
                height: Number.isFinite(global.screen_height)
                    ? Math.max(1, global.screen_height)
                    : LENS_HEIGHT,
            };
        const roiValues = region.getROI?.();
        const roi = Array.isArray(roiValues) && roiValues.length >= 4 &&
            roiValues.slice(0, 4).every(Number.isFinite)
            ? {
                x: roiValues[0],
                y: roiValues[1],
                width: roiValues[2],
                height: roiValues[3],
            }
            : null;
        const factorValues = region.getMagFactor?.();
        const factors = Array.isArray(factorValues) && factorValues.length >= 2 &&
            factorValues.slice(0, 2).every(value => Number.isFinite(value) && value > 0)
            ? {
                x: Math.max(MIN_ZOOM, factorValues[0]),
                y: Math.max(MIN_ZOOM, factorValues[1]),
            }
            : null;

        return {
            viewport,
            roi,
            factors,
            screenPosition: typeof region.getScreenPosition === 'function'
                ? region.getScreenPosition()
                : null,
            lensMode: typeof region.isLensMode === 'function' && region.isLensMode(),
            backgroundVisible: typeof region._background?.visible === 'boolean'
                ? region._background.visible
                : null,
            backgroundOpacity: Number.isFinite(region._background?.opacity)
                ? region._background.opacity
                : null,
            backgroundStyle: typeof region._background?.get_style === 'function'
                ? region._background.get_style()
                : null,
            magViewStyle: typeof region._magView?.get_style === 'function'
                ? region._magView.get_style()
                : null,
            magViewHasMagnifierClass: typeof region._magView?.has_style_class_name === 'function'
                ? region._magView.has_style_class_name('magnifier-zoom-region')
                : null,
        };
    }

    _setLensMode(active) {
        if (active === this._lensActive)
            return active;

        if (active) {
            const region = this._region();
            if (!region || typeof region.setLensMode !== 'function' ||
                typeof region.setViewPort !== 'function')
                return false;

            const wasActive = this._actualActive();
            const wasEnabled = this._apps.get_boolean(ENABLED_KEY);
            const state = this._captureLensRegionState(region);
            const previousFactor = wasActive ? this._liveFactor() : MIN_ZOOM;
            const storedLensFactor = this._settings?.get_double?.(LENS_ZOOM_KEY);
            const lensFactor = Number.isFinite(storedLensFactor) && storedLensFactor >= MIN_ZOOM
                ? Math.min(this._maximum, Math.max(MIN_ZOOM, storedLensFactor))
                : previousFactor;
            state.factors = {x: previousFactor, y: previousFactor};
            this._lensRegionState = state;
            this._lensWasActive = wasActive;
            this._lensWasEnabled = wasEnabled;

            try {
                if (!wasActive) {
                    Main.magnifier?.setActive?.(true);
                    this._active = true;
                }

                this._lensActive = true;
                region._clearScrollContentsTimer?.();
                if ('_followingCursor' in region)
                    region._followingCursor = false;
                region.setLensMode(true);
                const {width, height} = this._lensViewportSize();
                region.setViewPort({x: 0, y: 0, width, height});
                region.setMagFactor?.(lensFactor, lensFactor);
                this._target = lensFactor;
                this._visualFactor = lensFactor;
                this._rememberLensZoom(lensFactor);
                this._applyTracking();
                this._createLensFrame();
                this._positionLensFrame();
                this._clearLensTint(region);
                this._animateLensIn(region);
                if (!this._animateLensToCursor(region))
                    throw new Error('native lens scrolling is unavailable');
                this._clearLensTint(region);
                this._startLensFollow();
                this._resumePointerTracking();
                return true;
            } catch (error) {
                this._logError('Could not enable lens mode', error);
                this._lensActive = false;
                this._cancelLensFollow();
                this._lensRegionState = null;
                this._lensFrame?.hide();
                try {
                    this._restoreLensRegion(region, state);
                    this._restoreLensActors(region);
                } catch (restoreError) {
                    this._logError('Could not restore viewport after lens failure', restoreError);
                }
                if (!wasActive) {
                    Main.magnifier?.setActive?.(false);
                    this._apps.set_boolean(ENABLED_KEY, wasEnabled);
                    this._active = false;
                }
                return false;
            }
        }

        const region = this._region();
        const state = this._lensRegionState;
        const wasActive = this._lensWasActive;
        const wasEnabled = this._lensWasEnabled;
        this._lensActive = false;
        this._cancelLensFollow();
        this._lensRegionState = null;
        this._lensFrame?.hide();

        try {
            this._restoreLensRegion(region, state);
            this._restoreLensActors(region);
            this._applyTracking();
            this._resumePointerTracking();

            if (!wasActive && this._currentFactor() <= MIN_ZOOM + ACTIVE_EPSILON) {
                Main.magnifier?.setActive?.(false);
                this._apps.set_boolean(ENABLED_KEY, wasEnabled);
                this._active = false;
            } else {
                this._active = this._actualActive();
            }
        } catch (error) {
            this._logError('Could not disable lens mode', error);
        }

        this._lensWasActive = false;
        this._lensWasEnabled = false;
        return true;
    }

    _clearLensTint(region) {
        if (region?._background) {
            region._background.opacity = 0;
            region._background.hide?.();
        }

        const magView = region?._magView;
        magView?.remove_style_class_name?.('magnifier-zoom-region');
        magView?.set_style?.('background-color: rgba(0, 0, 0, 0);');
    }

    _restoreLensRegion(region, state) {
        if (!region || !state)
            return;

        region._clearScrollContentsTimer?.();
        if ('_followingCursor' in region)
            region._followingCursor = false;
        if (typeof region.setLensMode === 'function')
            region.setLensMode(false);
        const savedFactors = state.factors;
        const currentFactors = region.getMagFactor?.();
        const xFactor = Number.isFinite(savedFactors?.x)
            ? Math.max(MIN_ZOOM, savedFactors.x)
            : Number.isFinite(currentFactors?.[0])
                ? Math.max(MIN_ZOOM, currentFactors[0])
                : null;
        const yFactor = Number.isFinite(savedFactors?.y)
            ? Math.max(MIN_ZOOM, savedFactors.y)
            : Number.isFinite(currentFactors?.[1])
                ? Math.max(MIN_ZOOM, currentFactors[1])
                : null;
        if (xFactor)
            this._magnifier?.set_double?.(FACTOR_KEY, xFactor);
        if (typeof region.setViewPort === 'function')
            region.setViewPort({...state.viewport});
        if (state.screenPosition !== null && state.screenPosition !== undefined &&
            typeof region.setScreenPosition === 'function')
            region.setScreenPosition(state.screenPosition);
        if (state.roi && typeof region.setROI === 'function') {
            if (xFactor && yFactor) {
                region.setROI({
                    x: state.roi.x + state.roi.width / 2 - state.viewport.width / xFactor / 2,
                    y: state.roi.y + state.roi.height / 2 - state.viewport.height / yFactor / 2,
                    width: state.viewport.width / xFactor,
                    height: state.viewport.height / yFactor,
                });
            } else {
                region.setROI({...state.roi});
            }
        } else if (xFactor && yFactor && typeof region.setMagFactor === 'function') {
            region.setMagFactor(xFactor, yFactor);
        }
        if (state.magViewHasMagnifierClass === true)
            region._magView?.add_style_class_name?.('magnifier-zoom-region');
        if (state.magViewStyle !== null && region._magView?.set_style)
            region._magView.set_style(state.magViewStyle);
        if (region._background) {
            if (Number.isFinite(state.backgroundOpacity))
                region._background.opacity = state.backgroundOpacity;
            if (state.backgroundStyle !== null && region._background.set_style)
                region._background.set_style(state.backgroundStyle);
            if (state.backgroundVisible === false)
                region._background.hide?.();
            else
                region._background.show?.();
        }
        if (state.lensMode && typeof region.setLensMode === 'function')
            region.setLensMode(true);
    }

    _animateLensToCursor(region) {
        const [x, y] = global.get_pointer();
        if (!Number.isFinite(x) || !Number.isFinite(y))
            return false;

        try {
            if (typeof region.scrollContentsTo === 'function') {
                region.scrollContentsTo(x, y);
                return true;
            }
            if (typeof region._changeROI === 'function') {
                region._changeROI({xCenter: x, yCenter: y, animate: true});
                return true;
            }
        } catch (error) {
            this._logError('Could not move lens to pointer', error);
        }
        return false;
    }

    _createLensFrame() {
        if (!this._lensFrame) {
            this._lensFrame = new St.Widget({
                style_class: 'pinch-magnifier-lens-frame',
                reactive: false,
            });
            global.stage.add_child(this._lensFrame);
        }
        this._lensFrame.show();
    }

    _animateLensIn(region) {
        const duration = this._interface?.get_boolean?.('enable-animations') === false
            ? 0
            : LENS_ANIMATION_MS;
        for (const actor of [region?._magView, this._lensFrame]) {
            if (!actor)
                continue;

            actor.remove_all_transitions?.();
            actor.set_pivot_point?.(0.5, 0.5);
            actor.opacity = 0;
            actor.scale_x = 0.94;
            actor.scale_y = 0.94;
            if (duration && actor.ease) {
                actor.ease({
                    opacity: 255,
                    scale_x: 1,
                    scale_y: 1,
                    duration,
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                });
            } else {
                actor.opacity = 255;
                actor.scale_x = 1;
                actor.scale_y = 1;
            }
        }
    }

    _restoreLensActors(region) {
        for (const actor of [region?._magView, this._lensFrame]) {
            if (!actor)
                continue;

            actor.remove_all_transitions?.();
            actor.opacity = 255;
            actor.scale_x = 1;
            actor.scale_y = 1;
        }
    }

    _positionLensFrame() {
        if (!this._lensFrame || !this._lensActive)
            return;

        const viewport = this._lensViewportRect();
        const region = this._region();
        const setViewport = region?._setViewPort?.bind(region) ??
            region?.setViewPort?.bind(region);
        if (setViewport &&
            (region._viewPortX !== viewport.x ||
             region._viewPortY !== viewport.y ||
             region._viewPortWidth !== viewport.width ||
             region._viewPortHeight !== viewport.height))
            setViewport({...viewport}, true);

        this._lensFrame.set_size(viewport.width, viewport.height);
        this._lensFrame.set_position(viewport.x, viewport.y);
        global.stage.set_child_above_sibling(this._lensFrame, null);
    }

    _startLensFollow() {
        if (this._lensFollowId)
            return;

        this._lensFollowId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            LENS_FOLLOW_MS,
            () => {
                if (!this._lensActive) {
                    this._lensFollowId = 0;
                    return GLib.SOURCE_REMOVE;
                }

                try {
                    this._positionLensFrame();
                } catch (error) {
                    this._logError('Could not follow pointer with lens', error);
                    this._lensFollowId = 0;
                    return GLib.SOURCE_REMOVE;
                }
                return true;
            }
        );
    }

    _cancelLensFollow() {
        if (!this._lensFollowId)
            return;

        GLib.Source.remove(this._lensFollowId);
        this._lensFollowId = 0;
    }

    _clearLensHold() {
        if (!this._rightCtrlHoldId)
            return;

        GLib.Source.remove(this._rightCtrlHoldId);
        this._rightCtrlHoldId = 0;
    }

    _pointerModifierState() {
        try {
            const pointer = global.get_pointer?.();
            const modifiers = Array.isArray(pointer) ? pointer[2] : null;
            return Number.isFinite(modifiers) ? modifiers : null;
        } catch (_error) {
            return null;
        }
    }

    _clearModifierReleaseWatch() {
        if (!this._modifierReleaseWatchId)
            return;

        GLib.Source.remove(this._modifierReleaseWatchId);
        this._modifierReleaseWatchId = 0;
    }

    _updateModifierReleaseWatch() {
        const modifierDown = this._leftAltDown || this._rightAltDown ||
            this._rightCtrlDown;
        if (!modifierDown) {
            this._clearModifierReleaseWatch();
            return;
        }

        if (this._modifierReleaseWatchId)
            return;

        this._modifierReleaseWatchId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            MODIFIER_RELEASE_POLL_MS,
            () => {
                this._modifierReleaseWatchId = 0;
                const modifiers = this._pointerModifierState();
                if (modifiers !== null) {
                    if (this._leftAltDown && !(modifiers & ALT_MODIFIER_MASK))
                        this._handleShortcutEvent(this._shortcutKeyEvent(
                            Clutter.EventType.KEY_RELEASE,
                            Clutter.KEY_Alt_L
                        ));
                    if (this._rightAltDown && !(modifiers & ALT_MODIFIER_MASK))
                        this._handleShortcutEvent(this._shortcutKeyEvent(
                            Clutter.EventType.KEY_RELEASE,
                            Clutter.KEY_Alt_R
                        ));
                    if (this._rightCtrlDown &&
                        !(modifiers & CONTROL_MODIFIER_MASK))
                        this._handleShortcutEvent(this._shortcutKeyEvent(
                            Clutter.EventType.KEY_RELEASE,
                            Clutter.KEY_Control_R
                        ));
                }

                this._updateModifierReleaseWatch();
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _shortcutKeyEvent(type, symbol) {
        return {
            type: () => type,
            get_key_symbol: () => symbol,
        };
    }

    _cancelLensShortcut(restoreTemporary = false) {
        this._clearLensHold();
        if (restoreTemporary && this._rightCtrlTemporary)
            this._setLensMode(false);

        this._rightCtrlDown = false;
        this._rightCtrlUsedWithOtherKey = false;
        this._rightCtrlHoldActivated = false;
        this._rightCtrlWasActive = false;
        this._rightCtrlTemporary = false;
    }

    _fingerCount(event) {
        return event.get_touchpad_gesture_finger_count?.() ??
            event.get_gesture_swipe_finger_count?.() ??
            0;
    }

    _claimGesture() {
        if (this._gestureGrab)
            return true;

        try {
            const grab = global.stage.grab(global.stage);

            if (!grab || grab.is_revoked?.()) {
                grab?.dismiss?.();
                return false;
            }

            this._gestureGrab = grab;
            return true;
        } catch (error) {
            this._logError('Could not claim three-finger pinch', error);
            return false;
        }
    }

    _releaseGestureGrab() {
        const grab = this._gestureGrab;
        this._gestureGrab = null;

        try {
            grab?.dismiss?.();
        } catch (error) {
            this._logError('Could not release pinch grab', error);
        }
    }

    _armWatchdog() {
        this._disarmWatchdog();
        this._touchWatchdog();
        this._watchdogId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            WATCHDOG_POLL_MS,
            () => {
                if (!this._gesture) {
                    this._watchdogId = 0;
                    return GLib.SOURCE_REMOVE;
                }

                const idleMs = (GLib.get_monotonic_time() - this._lastPinchAtUs) / 1000;
                if (idleMs < WATCHDOG_MS)
                    return GLib.SOURCE_CONTINUE;

                this._watchdogId = 0;
                this._handleGestureFailure(new Error('pinch gesture timed out'));
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _touchWatchdog() {
        this._lastPinchAtUs = GLib.get_monotonic_time();
    }

    _disarmWatchdog() {
        if (!this._watchdogId)
            return;

        GLib.Source.remove(this._watchdogId);
        this._watchdogId = 0;
    }

    _begin() {
        this._cancelFrame();
        this._shortcutAnimating = false;
        this._shortcutAnimationStartUs = 0;
        this._shortcutAnimationDurationUs = 0;
        this._settling = false;
        this._startAppEnabled = this._apps.get_boolean(ENABLED_KEY);
        this._startEnabled = this._actualActive();
        this._startStored = this._magnifier.get_double(FACTOR_KEY);
        this._start = this._startEnabled ? this._liveFactor() : MIN_ZOOM;
        this._startROI = this._startEnabled ? this._captureROI() : null;
        this._active = this._startEnabled;
        this._target = this._start;
        this._visualFactor = this._start;
        this._inputScale = 1;
        const nowUs = GLib.get_monotonic_time();
        this._lastFrameTimeUs = nowUs;
        this._lastInputTimeUs = nowUs;
        this._inputSpeed = 0;
        this._settleDeadlineUs = 0;
        this._gesture = true;
        this._gestureTracking = {
            focus: this._magnifier.get_string('focus-tracking'),
            caret: this._magnifier.get_string('caret-tracking'),
        };
        this._writeTrackingRecovery();
        this._applyTracking();
        this._prewarmMagnifier();
        this._gestureAnchor = this._startEnabled
            ? this._captureGestureAnchor(this._region())
            : null;
        this._armWatchdog();
        this._show(this._start, true);
    }

    _update(event) {
        this._touchWatchdog();
        const scale = Number(event.get_gesture_pinch_scale());
        if (!Number.isFinite(scale) || scale <= 0)
            return;

        const previousScale = Number.isFinite(this._inputScale) && this._inputScale > 0
            ? this._inputScale
            : 1;
        const previousTarget = this._target;
        const next = zoomForScaleDelta(
            previousTarget,
            previousScale,
            scale,
            this._sensitivity,
            this._maximum,
            this._inverted
        );
        this._inputScale = scale;

        const nowUs = GLib.get_monotonic_time();
        const elapsedSeconds = (nowUs - this._lastInputTimeUs) / 1_000_000;
        if (elapsedSeconds > 0 && previousTarget > 0 && next > 0)
            this._inputSpeed = Math.abs(Math.log(next / previousTarget)) / elapsedSeconds;
        else
            this._inputSpeed = 0;
        this._lastInputTimeUs = nowUs;

        // Each delta starts from the already-clamped target. Finger travel past
        // either zoom boundary is therefore discarded and reversal is immediate.
        if (Math.abs(next - this._target) < CHANGE_EPSILON)
            return;

        this._queueLive(next);
    }

    _queueLive(factor) {
        this._target = factor;
        this._ensureFrame();
    }

    _ensureFrame() {
        if (this._frameId || (!this._gesture && !this._settling))
            return;

        const serial = ++this._frameSerial;
        const laters = global.compositor.get_laters();
        this._frameId = laters.add(Meta.LaterType.BEFORE_REDRAW, () => {
            if (serial !== this._frameSerial)
                return GLib.SOURCE_REMOVE;

            this._frameId = 0;
            try {
                if (this._renderFrame())
                    this._ensureFrame();
            } catch (error) {
                if (this._gesture)
                    this._handleGestureFailure(error);
                else {
                    this._logError('Zoom settle failed', error);
                    this._shortcutAnimating = false;
                    this._shortcutAnimationStartUs = 0;
                    this._shortcutAnimationDurationUs = 0;
                    this._settling = false;
                    this._settleDeadlineUs = 0;
                    this._target = Number.isFinite(this._visualFactor)
                        ? this._visualFactor
                        : this._target;
                    const persisted = this._persist(this._target);
                    this._target = persisted;
                    this._visualFactor = persisted;
                    this._rememberZoom(persisted);
                    this._restoreGestureTracking();
                    this._applyTracking();
                    this._resumePointerTracking();
                    this._gestureAnchor = null;
                }
            }

            return GLib.SOURCE_REMOVE;
        });
    }

    _renderFrame() {
        if (!this._gesture && !this._settling)
            return false;

        const nowUs = GLib.get_monotonic_time();
        const dtMs = this._lastFrameTimeUs
            ? Math.min(MAX_FRAME_MS, Math.max(1, (nowUs - this._lastFrameTimeUs) / 1000))
            : 1000 / 60;
        this._lastFrameTimeUs = nowUs;

        const target = Math.min(this._maximum, Math.max(MIN_ZOOM, this._target));
        let visual = Number.isFinite(this._visualFactor) && this._visualFactor > 0
            ? this._visualFactor
            : target;
        if (this._shortcutAnimating) {
            const durationUs = Math.max(1, this._shortcutAnimationDurationUs);
            const progress = Math.min(1, Math.max(0,
                (nowUs - this._shortcutAnimationStartUs) / durationUs));
            const eased = 1 - Math.pow(1 - progress, 3);
            const start = Math.max(MIN_ZOOM, this._shortcutAnimationStartFactor);
            visual = Math.exp(
                Math.log(start) + eased * (Math.log(target) - Math.log(start))
            );
            if (progress >= 1)
                visual = target;
        } else {
            const tauMs = this._effectiveSmoothingMs();
            if (tauMs <= 0) {
                visual = target;
            } else {
                const alpha = 1 - Math.exp(-dtMs / tauMs);
                const logVisual = Math.log(visual);
                const logTarget = Math.log(target);
                visual = Math.exp(logVisual + alpha * (logTarget - logVisual));

                if (Math.abs(Math.log(target / visual)) <= LOG_SETTLE_EPSILON)
                    visual = target;
            }
        }

        if (this._settling && nowUs >= this._settleDeadlineUs)
            visual = target;

        visual = Math.min(this._maximum, Math.max(MIN_ZOOM, visual));

        this._setLive(visual);
        this._visualFactor = visual;
        this._show(visual, true);

        const atTarget = Math.abs(Math.log(target / visual)) <= LOG_SETTLE_EPSILON;
        if (this._settling && atTarget) {
            this._completeFinish();
            return false;
        }

        return !atTarget;
    }

    _effectiveSmoothingMs() {
        if (this._smoothingMs <= 0 || !this._interface.get_boolean('enable-animations'))
            return 0;

        if (this._settling)
            return Math.min(this._smoothingMs, RELEASE_TAU_MS);

        // Slow movement receives the configured filtering; fast movement gets
        // progressively less filtering to preserve reversals and responsiveness.
        const adaptation = 1 + Math.min(1.5, Math.max(0, this._inputSpeed) * 0.35);
        return Math.max(4, this._smoothingMs / adaptation);
    }

    _cancelFrame() {
        if (!this._frameId)
            return;

        const frameId = this._frameId;
        this._frameSerial++;
        this._frameId = 0;
        try {
            global.compositor.get_laters().remove?.(frameId);
        } catch (error) {
            this._logError('Could not remove pending zoom frame', error);
        }
    }

    _finish() {
        if (!this._gesture)
            return;

        // Snap only once input has ended. This avoids oscillation from repeated
        // or tiny samples around 100% while preserving a clean final 100% state.
        if (this._target < SNAP_AT)
            this._target = MIN_ZOOM;
        this._target = Math.min(this._maximum, Math.max(MIN_ZOOM, this._target));

        this._disarmWatchdog();
        this._inputSpeed = 0;
        this._gesture = false;
        this._settling = true;
        this._settleDeadlineUs = GLib.get_monotonic_time() + RELEASE_SETTLE_MS * 1000;
        this._applyTracking();
        this._releaseGestureGrab();
        this._ensureFrame();
    }

    _completeFinish() {
        const target = Math.min(this._maximum, Math.max(MIN_ZOOM, this._target));
        this._shortcutAnimating = false;
        this._shortcutAnimationStartUs = 0;
        this._shortcutAnimationStartFactor = target;
        this._shortcutAnimationDurationUs = 0;
        this._settling = false;
        this._settleDeadlineUs = 0;
        this._target = target;
        this._visualFactor = target;
        const persisted = this._persist(target);
        this._target = persisted;
        this._visualFactor = persisted;
        this._rememberZoom(persisted);
        this._restoreGestureTracking();
        this._applyTracking();
        this._resumePointerTracking();
        this._gestureAnchor = null;
        this._show(persisted, false);
    }

    _interruptSettling() {
        this._cancelFrame();
        this._shortcutAnimating = false;
        this._shortcutAnimationStartUs = 0;
        this._shortcutAnimationDurationUs = 0;
        this._settling = false;
        this._settleDeadlineUs = 0;

        const current = Number.isFinite(this._visualFactor)
            ? this._visualFactor
            : this._target;
        this._target = Math.min(this._maximum, Math.max(MIN_ZOOM, current));
        const persisted = this._persist(this._target);
        this._target = persisted;
        this._visualFactor = persisted;
        this._rememberZoom(persisted);
        this._restoreGestureTracking();
        this._applyTracking();
        this._resumePointerTracking();
        this._gestureAnchor = null;
    }

    _cancel() {
        try {
            this._cancelFrame();
            this._disarmWatchdog();
            this._shortcutAnimating = false;
            this._shortcutAnimationStartUs = 0;
            this._shortcutAnimationDurationUs = 0;
            this._settling = false;
            this._settleDeadlineUs = 0;
            this._apps.set_boolean(ENABLED_KEY, this._startAppEnabled);
            this._magnifier.set_double(FACTOR_KEY, this._startStored);
            Main.magnifier?.setActive?.(this._startEnabled);
            this._active = this._startEnabled;

            if (this._startEnabled) {
                const region = this._region();
                if (region && this._startROI && region.setROI)
                    region.setROI({...this._startROI});
                else
                    region?.setMagFactor?.(this._start, this._start);
            }

            this._visualFactor = this._start;
            this._target = this._start;
            this._inputSpeed = 0;
            this._gestureAnchor = null;
            this._show(this._start, false);
        } finally {
            this._gesture = false;
            this._settling = false;
            try {
                this._restoreGestureTracking();
                this._applyTracking();
                this._resumePointerTracking();
            } catch (error) {
                this._logError('Could not resume pointer tracking after pinch', error);
            }
            this._releaseGestureGrab();
        }
    }

    _handleGestureFailure(error) {
        this._logError('Pinch update failed; releasing gesture ownership', error);

        try {
            this._cancel();
        } catch (restoreError) {
            this._logError('Could not fully restore state after pinch failure', restoreError);
            this._cancelFrame();
            this._disarmWatchdog();
            this._gesture = false;
            this._settling = false;
            this._gestureAnchor = null;
            try {
                this._restoreGestureTracking();
                this._applyTracking();
                this._resumePointerTracking();
            } catch (error) {
                this._logError('Could not resume tracking after pinch failure', error);
            }
            this._releaseGestureGrab();
        } finally {
            this._ignoreUntilBegin = true;
        }
    }

    _actualActive() {
        try {
            const active = Main.magnifier?.isActive?.();
            if (typeof active === 'boolean')
                return active;
        } catch (error) {
            this._logError('Could not query live magnifier state', error);
        }

        return this._apps.get_boolean(ENABLED_KEY);
    }

    _region() {
        return Main.magnifier?.getZoomRegions?.()?.[0] ?? null;
    }
    _captureROI() {
        const roi = this._region()?.getROI?.();
        if (!Array.isArray(roi) || roi.length < 4 || !roi.every(Number.isFinite))
            return null;

        return {x: roi[0], y: roi[1], width: roi[2], height: roi[3]};
    }

    _liveFactor() {
        const factors = this._region()?.getMagFactor?.();
        return Number.isFinite(factors?.[0])
            ? Math.max(MIN_ZOOM, factors[0])
            : Math.max(MIN_ZOOM, this._magnifier.get_double(FACTOR_KEY));
    }

    _prewarmMagnifier() {
        if (this._startEnabled || this._actualActive())
            return;

        this._magnifier.set_double(FACTOR_KEY, MIN_ZOOM);
        Main.magnifier?.setActive?.(true);
        this._active = true;
        this._region()?.setMagFactor?.(MIN_ZOOM, MIN_ZOOM);
    }

    _setLive(factor) {
        factor = Number.isFinite(factor)
            ? Math.min(this._maximum, Math.max(MIN_ZOOM, factor))
            : MIN_ZOOM;
        const requestedActive = factor > MIN_ZOOM + ACTIVE_EPSILON;
        const shouldBeActive = this._lensActive ||
            this._gesture || this._settling || requestedActive;
        this._active = this._actualActive();

        if (shouldBeActive !== this._active) {
            // Establish the requested factor while the region is still hidden,
            // so activation starts from the current pinch rather than a stale
            // stored magnification from an earlier session.
            if (shouldBeActive)
                this._region()?.setMagFactor?.(factor, factor);

            Main.magnifier?.setActive?.(shouldBeActive);
            if (!this._gesture && !this._settling)
                this._apps.set_boolean(ENABLED_KEY, shouldBeActive);
            this._active = shouldBeActive;
        }

        if (!shouldBeActive)
            return;

        const region = this._region();
        if (region) {
            if (!this._setAnchoredRegionFactor(region, factor))
                region.setMagFactor?.(factor, factor);
        } else {
            this._magnifier.set_double(FACTOR_KEY, factor);
        }
    }

    _captureGestureAnchor(region) {
        if (!region?.getROI || !region?.getMagFactor)
            return null;

        const roi = region.getROI();
        const factors = region.getMagFactor();
        const factor = Number(factors?.[0]);
        if (!Array.isArray(roi) || roi.length < 4 ||
            !roi.every(Number.isFinite) || !Number.isFinite(factor) || factor <= 0) {
            return null;
        }

        const [roiX, roiY, roiWidth, roiHeight] = roi;
        const viewX = Number.isFinite(region._viewPortX) ? region._viewPortX : 0;
        const viewY = Number.isFinite(region._viewPortY) ? region._viewPortY : 0;
        const viewWidth = Number.isFinite(region._viewPortWidth)
            ? region._viewPortWidth
            : roiWidth * factor;
        const viewHeight = Number.isFinite(region._viewPortHeight)
            ? region._viewPortHeight
            : roiHeight * factor;

        if (viewWidth <= 0 || viewHeight <= 0)
            return null;

        const [pointerX, pointerY] = global.get_pointer();
        const pointerInside = pointerX >= viewX && pointerX <= viewX + viewWidth &&
            pointerY >= viewY && pointerY <= viewY + viewHeight;
        const anchorScreenX = pointerInside ? pointerX : viewX + viewWidth / 2;
        const anchorScreenY = pointerInside ? pointerY : viewY + viewHeight / 2;

        return {
            region,
            viewX,
            viewY,
            viewWidth,
            viewHeight,
            anchorScreenX,
            anchorScreenY,
            anchorWorldX: roiX + (anchorScreenX - viewX) / factor,
            anchorWorldY: roiY + (anchorScreenY - viewY) / factor,
        };
    }

    _anchorGeometryChanged(anchor, region) {
        const geometry = [
            region?._viewPortX,
            region?._viewPortY,
            region?._viewPortWidth,
            region?._viewPortHeight,
        ];
        if (!geometry.every(Number.isFinite))
            return false;

        return Math.abs(geometry[0] - anchor.viewX) > 0.5 ||
            Math.abs(geometry[1] - anchor.viewY) > 0.5 ||
            Math.abs(geometry[2] - anchor.viewWidth) > 0.5 ||
            Math.abs(geometry[3] - anchor.viewHeight) > 0.5;
    }

    _setAnchoredRegionFactor(region, factor) {
        if (!region?.setROI || !Number.isFinite(factor) || factor <= 0)
            return false;

        let anchor = this._gestureAnchor;
        if (!anchor || anchor.region !== region || this._anchorGeometryChanged(anchor, region)) {
            anchor = this._captureGestureAnchor(region);
            if (!anchor)
                return false;
            this._gestureAnchor = anchor;
        }

        const newWidth = anchor.viewWidth / factor;
        const newHeight = anchor.viewHeight / factor;
        const newX = anchor.anchorWorldX -
            (anchor.anchorScreenX - anchor.viewX) / factor;
        const newY = anchor.anchorWorldY -
            (anchor.anchorScreenY - anchor.viewY) / factor;

        // Every frame derives from one gesture baseline, preventing pointer
        // jitter or previous viewport clamping from accumulating anchor drift.
        region.setROI({x: newX, y: newY, width: newWidth, height: newHeight});
        return true;
    }

    _resumePointerTracking() {
        const region = this._region();
        if (!region)
            return;
        // setROI suspends cursor-following; resume it without moving the ROI.
        if ('_followingCursor' in region)
            region._followingCursor = !this._viewportLocked &&
                !this._viewportUnlocking && !this._trackingChanging;
    }

    _persist(factor) {
        const finalFactor = Number.isFinite(factor)
            ? Math.min(this._maximum, Math.max(MIN_ZOOM, factor))
            : MIN_ZOOM;
        // GNOME stores magnification to two decimals and animates setting-driven
        // changes. Match that value before saving so it cannot correct the ROI
        // after the pinch has already finished.
        const persistedFactor = Number(finalFactor.toFixed(2));
        if (this._lensActive)
            this._rememberLensZoom(persistedFactor);
        const active = this._lensActive ||
            persistedFactor > MIN_ZOOM + ACTIVE_EPSILON;
        if (active && this._gestureAnchor)
            this._setAnchoredRegionFactor(this._region(), persistedFactor);
        this._magnifier.set_double(FACTOR_KEY, active ? persistedFactor : MIN_ZOOM);
        Main.magnifier?.setActive?.(active);
        this._apps.set_boolean(ENABLED_KEY, active);
        this._active = active;
        return active ? persistedFactor : MIN_ZOOM;
    }

    _currentFactor() {
        if (this._gesture)
            return this._target;
        if (this._settling && Number.isFinite(this._visualFactor))
            return this._visualFactor;

        return this._actualActive() ? this._liveFactor() : MIN_ZOOM;
    }

    _rememberZoom(factor) {
        if (this._lensActive || !Number.isFinite(factor) ||
            factor <= MIN_ZOOM + ACTIVE_EPSILON)
            return;

        const remembered = Math.min(this._maximum, Math.max(MIN_ZOOM, factor));
        this._previousZoom = remembered;

        if (Math.abs(this._settings.get_double(PREVIOUS_ZOOM_KEY) - remembered) > CHANGE_EPSILON)
            this._settings.set_double(PREVIOUS_ZOOM_KEY, remembered);
    }

    _rememberLensZoom(factor) {
        if (!Number.isFinite(factor))
            return;

        const maximum = Number.isFinite(this._maximum) ? this._maximum : factor;
        const remembered = Math.min(maximum, Math.max(MIN_ZOOM, factor));
        if (Math.abs(this._settings.get_double(LENS_ZOOM_KEY) - remembered) > CHANGE_EPSILON)
            this._settings.set_double(LENS_ZOOM_KEY, remembered);
    }

    _prepareShortcutZoom() {
        const wasGesture = this._gesture;
        this._cancelFrame();
        this._disarmWatchdog();
        this._shortcutAnimating = false;
        this._shortcutAnimationStartUs = 0;
        this._shortcutAnimationDurationUs = 0;
        this._gesture = false;
        this._settling = false;
        this._settleDeadlineUs = 0;
        this._gestureAnchor = null;
        this._inputSpeed = 0;
        this._restoreGestureTracking();
        this._applyTracking();
        this._resumePointerTracking();
        this._releaseGestureGrab();

        if (wasGesture)
            this._ignoreUntilBegin = true;
    }

    _startShortcutZoom(target) {
        const current = this._currentFactor();
        const next = Math.min(this._maximum, Math.max(MIN_ZOOM, target));
        const anchor = this._actualActive()
            ? this._captureGestureAnchor(this._region())
            : null;
        this._prepareShortcutZoom();
        this._target = next;
        this._visualFactor = current;
        this._inputScale = 1;
        this._gestureAnchor = anchor;

        const nowUs = GLib.get_monotonic_time();
        const duration = this._interface?.get_boolean?.('enable-animations') === false
            ? 0
            : SHORTCUT_ZOOM_MS;
        this._lastFrameTimeUs = nowUs;
        this._shortcutAnimationStartUs = nowUs;
        this._shortcutAnimationStartFactor = current;
        this._shortcutAnimationDurationUs = duration * 1000;
        this._shortcutAnimating = duration > 0;
        this._settling = this._shortcutAnimating;
        this._settleDeadlineUs = nowUs + this._shortcutAnimationDurationUs;
        this._applyTracking();

        if (!this._shortcutAnimating) {
            this._setLive(next);
            this._visualFactor = next;
            this._completeFinish();
            return;
        }

        this._ensureFrame();
    }

    _beginTrackingCycleCombo() {
        if (this._trackingCycleCombo)
            return;

        this._trackingCycleCombo = true;
        this._endFnDirectionalFollow();
        this._cancelToggleShortcut(true);
    }

    _finishTrackingCycleCombo() {
        if (this._leftAltDown || this._fnDown || !this._trackingCycleCombo)
            return;

        this._trackingCycleCombo = false;
        this._cycleTracking();
    }

    _animateViewportToCursor(region) {
        const [x, y] = global.get_pointer();
        const center = this._cursorTargetCenter(region, x, y);
        if (!center)
            return false;

        try {
            if (typeof region.scrollContentsTo === 'function') {
                region.scrollContentsTo(center[0], center[1]);
                return true;
            }
            if (typeof region._changeROI === 'function') {
                region._changeROI({
                    xCenter: center[0],
                    yCenter: center[1],
                    animate: true,
                });
                return true;
            }
        } catch (error) {
            this._logError('Could not animate viewport to cursor', error);
        }
        return false;
    }

    _lockViewport() {
        if (this._trackingChanging)
            this._cancelTrackingChange();
        if (this._viewportLocked || this._viewportUnlocking)
            return;

        const region = this._region();
        if (!region || !this._actualActive())
            return;

        this._lockedTracking = {
            focus: this._magnifier.get_string('focus-tracking'),
            caret: this._magnifier.get_string('caret-tracking'),
        };
        this._viewportLocked = true;
        region._clearScrollContentsTimer?.();
        if ('_followingCursor' in region)
            region._followingCursor = false;
        this._applyTracking();
    }

    _cursorTargetCenter(region, x, y) {
        if (!Number.isFinite(x) || !Number.isFinite(y))
            return null;

        let center = [x, y];
        try {
            const method = this._tracking === 'proportional'
                ? region._centerFromPointProportional
                : this._tracking === 'push'
                    ? region._centerFromPointPush
                    : region._centerFromPointCentered;
            if (typeof method === 'function')
                center = method.call(region, x, y);
        } catch (error) {
            this._logError('Could not calculate viewport target', error);
        }

        return Array.isArray(center) && center.length >= 2 &&
            Number.isFinite(center[0]) && Number.isFinite(center[1])
            ? center
            : [x, y];
    }

    _unlockViewport() {
        if (!this._viewportLocked || this._viewportUnlocking)
            return;
        if (this._trackingChanging)
            this._cancelTrackingChange();

        const region = this._region();
        if (!region) {
            this._finishViewportUnlock();
            return;
        }

        this._viewportUnlocking = true;
        region._clearScrollContentsTimer?.();
        if ('_followingCursor' in region)
            region._followingCursor = false;
        this._applyTracking();

        if (!this._animateViewportToCursor(region)) {
            this._finishViewportUnlock();
            return;
        }

        this._viewportUnlockId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            VIEWPORT_UNLOCK_MS,
            () => {
                this._viewportUnlockId = 0;
                this._finishViewportUnlock();
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _finishViewportUnlock() {
        const region = this._region();
        const tracking = this._lockedTracking;
        this._lockedTracking = null;
        this._viewportUnlocking = false;
        this._viewportLocked = false;

        if (tracking) {
            for (const [key, value] of [
                ['focus-tracking', tracking.focus],
                ['caret-tracking', tracking.caret],
            ]) {
                try {
                    this._magnifier.set_string(key, value);
                } catch (error) {
                    this._logError(`Could not restore ${key}`, error);
                }
            }
        }

        this._applyTracking();
        this._resumePointerTracking();
    }

    _cancelViewportUnlock() {
        if (this._viewportUnlockId) {
            GLib.Source.remove(this._viewportUnlockId);
            this._viewportUnlockId = 0;
        }

        if (!this._viewportLocked && !this._viewportUnlocking &&
            !this._lockedTracking)
            return;

        this._finishViewportUnlock();
    }

    _cycleTracking() {
        if (this._viewportUnlocking)
            return;
        if (this._trackingChanging)
            this._cancelTrackingChange();

        const currentIndex = TRACKING_CYCLE.indexOf(this._tracking);
        const next = TRACKING_CYCLE[(currentIndex + 1) % TRACKING_CYCLE.length];
        const region = this._region();
        if (!region || !this._actualActive()) {
            this._settings.set_string('mouse-tracking', next);
            return;
        }

        this._trackingChangeTracking = {
            focus: this._magnifier.get_string('focus-tracking'),
            caret: this._magnifier.get_string('caret-tracking'),
        };
        this._trackingChanging = true;
        try {
            this._settings.set_string('mouse-tracking', next);
            this._readSettings();
        } catch (error) {
            this._logError('Could not change pointer tracking mode', error);
            this._finishTrackingChange();
            return;
        }

        region._clearScrollContentsTimer?.();
        if ('_followingCursor' in region)
            region._followingCursor = false;
        this._applyTracking();
        if (!this._animateViewportToCursor(region)) {
            this._finishTrackingChange();
            return;
        }

        this._trackingChangeId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT,
            VIEWPORT_UNLOCK_MS,
            () => {
                this._trackingChangeId = 0;
                this._finishTrackingChange();
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _finishTrackingChange() {
        if (this._trackingChangeId) {
            GLib.Source.remove(this._trackingChangeId);
            this._trackingChangeId = 0;
        }
        if (!this._trackingChanging)
            return;

        const tracking = this._trackingChangeTracking;
        this._trackingChangeTracking = null;
        this._trackingChanging = false;
        if (tracking) {
            for (const [key, value] of [
                ['focus-tracking', tracking.focus],
                ['caret-tracking', tracking.caret],
            ]) {
                try {
                    this._magnifier.set_string(key, value);
                } catch (error) {
                    this._logError(`Could not restore ${key}`, error);
                }
            }
        }
        this._applyTracking();
        this._resumePointerTracking();
    }

    _cancelTrackingChange() {
        if (this._trackingChangeId) {
            GLib.Source.remove(this._trackingChangeId);
            this._trackingChangeId = 0;
        }
        if (!this._trackingChanging)
            return;

        const tracking = this._trackingChangeTracking;
        this._trackingChangeTracking = null;
        this._trackingChanging = false;
        if (tracking) {
            for (const [key, value] of [
                ['focus-tracking', tracking.focus],
                ['caret-tracking', tracking.caret],
            ]) {
                try {
                    this._magnifier.set_string(key, value);
                } catch (error) {
                    this._logError(`Could not restore ${key}`, error);
                }
            }
        }
        this._applyTracking();
        this._resumePointerTracking();
    }

    _clearToggleHold(state = this._toggleShortcutState) {
        if (!state.holdId)
            return;

        GLib.Source.remove(state.holdId);
        state.holdId = 0;
    }

    _cancelToggleShortcut(restoreTemporary = false, state = this._toggleShortcutState) {
        this._clearToggleHold(state);
        if (restoreTemporary && state.temporary)
            this._reset(true);

        state.down = false;
        state.holdActivated = false;
        state.wasActive = false;
        state.temporary = false;
        state.usedWithOtherKey = false;
    }

    _handleToggleShortcut(event, state = this._toggleShortcutState) {
        const type = this._eventType(event);
        if (type === Clutter.EventType.KEY_PRESS) {
            if (state.down)
                return;

            state.down = true;
            state.holdActivated = false;
            state.wasActive = this._currentFactor() > MIN_ZOOM + ACTIVE_EPSILON;
            state.temporary = false;
            state.holdId = GLib.timeout_add(
                GLib.PRIORITY_DEFAULT,
                HOLD_ACTIVATION_MS,
                () => {
                    state.holdId = 0;
                    if (!state.down)
                        return GLib.SOURCE_REMOVE;

                    state.holdActivated = true;
                    if (!state.wasActive) {
                        this._togglePrevious();
                        state.temporary = this._target > MIN_ZOOM + ACTIVE_EPSILON;
                    }
                    return GLib.SOURCE_REMOVE;
                }
            );
            return;
        }

        if (type !== Clutter.EventType.KEY_RELEASE || !state.down)
            return;

        this._clearToggleHold(state);
        const held = state.holdActivated;
        const temporary = state.temporary;
        state.down = false;
        state.holdActivated = false;
        state.wasActive = false;
        state.temporary = false;
        state.usedWithOtherKey = false;

        if (held) {
            if (temporary)
                this._reset(true);
        } else {
            this._togglePrevious();
        }
    }

    _reset(animate = false) {
        if (this._trackingChanging)
            this._cancelTrackingChange();
        if (this._viewportLocked || this._viewportUnlocking)
            this._cancelViewportUnlock();
        if (this._lensActive)
            this._setLensMode(false);

        const current = this._currentFactor();
        this._rememberZoom(current);
        if (animate) {
            this._startShortcutZoom(MIN_ZOOM);
            return;
        }

        this._prepareShortcutZoom();
        this._target = MIN_ZOOM;
        this._visualFactor = MIN_ZOOM;
        this._inputScale = 1;
        this._setLive(MIN_ZOOM);
        this._persist(MIN_ZOOM);
        this._show(MIN_ZOOM, false);
    }

    _togglePrevious() {
        const current = this._currentFactor();
        if (current > MIN_ZOOM + ACTIVE_EPSILON) {
            this._rememberZoom(current);
            this._reset(true);
            return;
        }

        const next = Number(Math.min(this._maximum, Math.max(MIN_ZOOM, this._previousZoom)).toFixed(2));
        if (next <= MIN_ZOOM + ACTIVE_EPSILON)
            return;

        this._startShortcutZoom(next);
    }

    _createIndicator() {
        this._indicator = new St.Label({
            text: '1.0×',
            style_class: 'pinch-magnifier-osd',
            reactive: false,
            visible: false,
        });
        global.stage.add_child(this._indicator);
        this._indicatorAllocationId = this._indicator.connect(
            'notify::allocation',
            () => this._positionIndicator()
        );
        this._monitorsId = Main.layoutManager.connect(
            'monitors-changed',
            () => {
                this._positionIndicator();
                if (this._lensActive)
                    this._positionLensFrame();
            }
        );
        this._positionIndicator();
    }

    _positionIndicator() {
        if (!this._indicator)
            return;

        const monitor = Main.layoutManager.primaryMonitor;
        if (!monitor)
            return;

        const [width, height] = this._indicator.get_size();
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor || 1;
        const margin = Math.round(64 * scale);
        this._indicator.set_position(
            Math.round(monitor.x + (monitor.width - width) / 2),
            Math.round(monitor.y + monitor.height - height - margin)
        );
    }

    _show(factor, hold) {
        if (!this._showIndicator)
            return;

        this._cancelHide();
        this._indicator.text = `${factor.toFixed(1)}×`;
        this._positionIndicator();
        global.stage.set_child_above_sibling(this._indicator, null);

        if (!this._indicator.visible) {
            this._indicator.remove_all_transitions();
            this._indicator.opacity = 255;
            this._indicator.show();
        }

        if (!hold) {
            this._hideId = GLib.timeout_add(
                GLib.PRIORITY_DEFAULT,
                700,
                () => {
                    this._hideId = 0;
                    this._indicator?.ease({
                        opacity: 0,
                        duration: 140,
                        mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                        onComplete: () => this._indicator?.hide(),
                    });
                    return GLib.SOURCE_REMOVE;
                }
            );
        }
    }

    _cancelHide() {
        if (!this._hideId)
            return;
        GLib.Source.remove(this._hideId);
        this._hideId = 0;
    }

    _hideIndicator() {
        this._cancelHide();
        this._indicator?.remove_all_transitions();
        this._indicator?.hide();
    }

    _logError(message, error) {
        console.error(`[${this.uuid}] ${message}: ${error?.stack ?? error}`);
    }
}
