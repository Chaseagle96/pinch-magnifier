import Adw from 'gi://Adw';
import Gdk from 'gi://Gdk';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';

import {
    ExtensionPreferences,
    gettext as _,
} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class Preferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        this._handlerIds = [];
        const page = new Adw.PreferencesPage({
            title: _('Pinch Magnifier'),
            icon_name: 'zoom-in-symbolic',
        });
        window.add(page);
        window.set_default_size(620, 560);

        const feel = new Adw.PreferencesGroup({
            title: _('Feel'),
            description: _('Three fingers always control the desktop magnifier in real time.'),
        });
        page.add(feel);

        this._spin(feel, settings, 'sensitivity', _('Sensitivity'),
            _('How strongly finger movement changes magnification.'),
            0.5, 4, 0.05, 2);
        this._spin(feel, settings, 'smoothing-ms', _('Smoothing'),
            _('Adaptive follow time in milliseconds. Set to 0 for direct tracking.'),
            0, 50, 1, 0);
        this._spin(feel, settings, 'maximum-zoom', _('Maximum zoom'),
            _('The highest permitted magnification.'),
            2, 20, 0.5, 1);

        this._switch(feel, settings, 'invert-direction',
            _('Invert direction'),
            _('Pinching inward zooms in; spreading outward zooms out.'));

        const movement = new Adw.PreferencesGroup({
            title: _('Viewport'),
            description: _('GNOME handles panning; proportional tracking is the gentlest default. Press Fn + Left Alt to cycle tracking modes with a smooth reposition.'),
        });
        page.add(movement);

        this._combo(movement, settings, 'mouse-tracking',
            _('Pointer tracking'),
            [_('Proportional'), _('Centered'), _('Push at edges')],
            ['proportional', 'centered', 'push']);

        const interfaceGroup = new Adw.PreferencesGroup({
            title: _('Interface'),
        });
        page.add(interfaceGroup);

        this._switch(interfaceGroup, settings, 'show-indicator',
            _('Show zoom level'),
            _('Display a small magnification readout while pinching.'));

        const resetShortcut = this._shortcutLabel(settings, 'reset-shortcut');
        interfaceGroup.add(new Adw.ActionRow({
            title: _('Reset zoom'),
            subtitle: `${resetShortcut} — ${_('always returns to 100%')}`,
        }));

        const toggleRow = new Adw.ActionRow({
            title: _('Quick zoom shortcut'),
            subtitle: _('The configured shortcut taps or holds the previous zoom. Fn taps lock or unlock the viewport while zoomed; holding Fn constrains pointer movement to one cardinal axis until release. Left Alt, Right Alt, Fn, and Right Ctrl are captured globally when the keyboard exposes them as key events.'),
        });
        const toggleButton = new Gtk.Button({
            label: this._shortcutLabel(settings, 'toggle-shortcut'),
            valign: Gtk.Align.CENTER,
        });
        toggleButton.set_tooltip_text(_('Click, then press a key or key combination.'));
        toggleRow.add_suffix(toggleButton);
        let capturing = false;
        const toggleController = new Gtk.EventControllerKey();
        toggleController.connect('key-pressed', (_controller, keyval, _keycode, state) => {
            if (!capturing)
                return Gdk.EVENT_PROPAGATE;

            if (keyval === Gdk.KEY_Escape) {
                capturing = false;
                toggleButton.label = this._shortcutLabel(settings, 'toggle-shortcut');
                toggleButton.remove_css_class('suggested-action');
                return Gdk.EVENT_STOP;
            }

            const modifiers = keyval === Gdk.KEY_Alt_L
                ? 0
                : state & Gtk.accelerator_get_default_mod_mask();
            if (keyval !== Gdk.KEY_Alt_L && !Gtk.accelerator_valid(keyval, modifiers))
                return Gdk.EVENT_STOP;

            settings.set_strv('toggle-shortcut', [this._acceleratorName(keyval, modifiers)]);
            capturing = false;
            toggleButton.label = this._shortcutLabel(settings, 'toggle-shortcut');
            toggleButton.remove_css_class('suggested-action');
            return Gdk.EVENT_STOP;
        });
        toggleButton.add_controller(toggleController);
        toggleButton.connect('clicked', () => {
            capturing = true;
            toggleButton.label = _('Press a key…');
            toggleButton.add_css_class('suggested-action');
            toggleButton.grab_focus();
        });
        this._handlerIds.push(settings.connect('changed::toggle-shortcut', () => {
            if (!capturing)
                toggleButton.label = this._shortcutLabel(settings, 'toggle-shortcut');
        }));
        interfaceGroup.add(toggleRow);

        interfaceGroup.add(new Adw.ActionRow({
            title: _('Version'),
            subtitle: `v${this.metadata.version}`,
        }));

        window.connect('close-request', () => {
            for (const id of this._handlerIds)
                settings.disconnect(id);
            this._handlerIds = [];
        });
    }

    _shortcutLabel(settings, key) {
        const [accelerator] = settings.get_strv(key);
        if (!accelerator)
            return _('Disabled');
        if (accelerator === '<Alt>')
            return _('Left Alt');

        const [ok, keyval, modifiers] = Gtk.accelerator_parse(accelerator);
        if (!ok && accelerator === 'Fn')
            return 'Fn';
        return ok ? Gtk.accelerator_get_label(keyval, modifiers) : accelerator;
    }

    _acceleratorName(keyval, modifiers) {
        if (keyval === Gdk.KEY_Alt_L)
            return '<Alt>';

        const accelerator = Gtk.accelerator_name(keyval, modifiers);
        if (keyval === Gdk.KEY_Fn)
            return accelerator.replace(/0x[0-9a-f]+$/i, 'Fn');
        return accelerator;
    }

    _spin(group, settings, key, title, subtitle, lower, upper, step, digits) {
        const row = new Adw.SpinRow({
            title,
            subtitle,
            digits,
            adjustment: new Gtk.Adjustment({
                lower,
                upper,
                step_increment: step,
                page_increment: step * 5,
                value: settings.get_double(key),
            }),
        });
        settings.bind(key, row, 'value', Gio.SettingsBindFlags.DEFAULT);
        group.add(row);
    }

    _switch(group, settings, key, title, subtitle) {
        const row = new Adw.SwitchRow({title, subtitle});
        settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT);
        group.add(row);
    }

    _combo(group, settings, key, title, labels, values) {
        const row = new Adw.ComboRow({
            title,
            model: Gtk.StringList.new(labels),
            selected: Math.max(0, values.indexOf(settings.get_string(key))),
        });

        row.connect('notify::selected', () => {
            if (row.selected < values.length)
                settings.set_string(key, values[row.selected]);
        });
        this._handlerIds.push(settings.connect(`changed::${key}`, () => {
            const selected = values.indexOf(settings.get_string(key));
            if (selected >= 0 && row.selected !== selected)
                row.selected = selected;
        }));
        group.add(row);
    }
}
