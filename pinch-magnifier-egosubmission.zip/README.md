# Pinch Magnifier v28 — Persistent Lens and Global Shortcuts

A focused GNOME Shell extension for controlling GNOME's native magnifier with an exclusive three-finger pinch.

## What it does

- Three-finger spread zooms in continuously.
- Three-finger pinch zooms out continuously.
- Two-finger application gestures and three-finger swipes remain untouched.
- Pinch updates are coalesced onto Mutter's compositor redraw clock.
- Adaptive logarithmic smoothing defaults to 20 ms and can be set to 0 for direct tracking.
- Smoothing is automatically disabled when GNOME's animation preference is disabled.
- Zoom snaps to 100% only when a gesture ends below 1.03x.
- Travel beyond 100% or maximum zoom is discarded so reversals respond immediately.
- One pointer/content anchor is held for the full pinch and rebased only if viewport geometry changes.
- Native pointer, focus, and caret tracking are paused during a pinch and restored afterward.
- Existing keyboard-focus and text-caret magnifier tracking preferences are preserved.
- `Super` + `Shift` + `0` immediately resets to 100%.
- The quick zoom shortcut defaults to `Super` + `Shift` + `9` and is editable in Preferences. When zoomed out, tapping it toggles between 100% and the previous useful zoom; holding it for 250 ms temporarily shows the previous zoom until release. Both transitions are animated. Left and Right Alt provide this same quick zoom behavior when Left Alt is selected. A no-motion Fn tap independently locks or unlocks the viewport while zoomed.
- Left Alt is supported as a modifier-only quick zoom shortcut. Holding Fn constrains the pointer to the nearest horizontal or vertical direction until release, even at 1×; firmware-only Fn keys cannot be registered by GNOME Shell.
- Pressing Fn + Left Alt together cycles Proportional, Centered, and Push at edges tracking. The viewport animates to the new mode's cursor target instead of jumping.
- Right Ctrl toggles a cursor-following lens. Holding it temporarily enables the lens until release; its pane uses the last Lens magnification, appears with a short fade-and-scale animation, and follows the pointer without changing the full-screen viewport. Leaving Lens restores the full-screen zoom and content position from before activation.
- Reset, custom quick zoom, Left Alt, Right Alt, Fn, and Right Ctrl use Shell-wide non-maskable bindings, so they remain available over applications and GNOME Shell system surfaces. Modifier state is recovered if an application consumes a release. The Lens frame follows the native magnifier view over those surfaces.

## Zoom response

Each UPDATE uses only the newest change in cumulative pinch scale:

```text
ratio = current_pinch_scale / previous_pinch_scale
target = clamp(current_target × ratio^sensitivity, 1, maximum_zoom)
```

Because each ratio is applied to the already-clamped target, excess finger travel beyond either zoom limit is not accumulated.
## Smoothing

Visual zoom follows the target in logarithmic zoom space with a time-based exponential response. This keeps proportional feel consistent across magnification levels and refresh rates.

- Default time constant: `20 ms`.
- Range: `0–50 ms`.
- `0 ms`: direct frame-coalesced tracking.
- Fast movement automatically receives less filtering than slow movement.
- Gesture release uses a faster follow and a hard maximum settle window of `50 ms`.
- Emergency reset never waits for smoothing.

## Viewport anchoring

The extension captures the content point under the pointer at gesture BEGIN. Every visual update derives its ROI from that same baseline instead of recalculating from the current viewport and pointer position. This prevents pointer jitter and prior clamping from accumulating drift. If GNOME changes the viewport geometry during the gesture, the anchor is deliberately rebased.

## Recommended starting settings

- Sensitivity: `1.65`
- Smoothing: `20 ms`
- Maximum zoom: `12x`
- Pointer tracking: `Proportional`
- Indicator: off

For hardware comparison, test `20 ms` against `0 ms` first. If direct tracking feels better, leave smoothing at zero.
## Gesture ownership and failure handling

An exact three-finger pinch acquires a temporary Clutter stage grab. The grab is released on END, CANCEL, reset, initialization/update failure, and extension disable. A three-second inactivity watchdog also releases it if the compositor loses the gesture's final event. After an update failure or emergency reset, remaining events from that gesture are ignored until a fresh BEGIN.

GNOME's native magnifier performs the rendering. The extension controls target magnification and ROI geometry while the pinch is active, then restores normal pointer following afterward.

## GNOME 50 reload note

GNOME Shell 50 does not hot-reload an extension module with the same UUID. After changing `extension.js`, log out and back in to load the new code. Disabling and re-enabling the extension alone can leave the previous JavaScript module cached.

## License

Copyright (C) 2026 Chaseagle96

This project is licensed under the GNU General Public License, version 2 or (at your option) any later version. See [LICENSE](LICENSE).

SPDX-License-Identifier: GPL-2.0-or-later

## Warranty and liability

The extension is provided “AS IS”, without express or implied warranties, including merchantability or fitness for a particular purpose. Users assume all risk as to its quality and performance, including the cost of repair or correction. Except where required by law or agreed to in writing, copyright holders and contributors are not liable for damages arising from its use or inability to use it. See Sections 11 and 12 of [LICENSE](LICENSE).
