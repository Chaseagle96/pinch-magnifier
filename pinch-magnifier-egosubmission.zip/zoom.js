export const MIN_ZOOM = 1;

export function zoomForScale(
    start,
    scale,
    sensitivity,
    maximum,
    inverted = false
) {
    if (!Number.isFinite(scale) || scale <= 0)
        return start;

    const exponent = inverted ? -sensitivity : sensitivity;
    return Math.min(maximum, Math.max(MIN_ZOOM, start * scale ** exponent));
}

export function zoomForScaleDelta(
    current,
    previousScale,
    scale,
    sensitivity,
    maximum,
    inverted = false
) {
    if (!Number.isFinite(previousScale) || previousScale <= 0 ||
        !Number.isFinite(scale) || scale <= 0) {
        return current;
    }

    // Applying only the newest scale ratio to the already-clamped zoom
    // discards finger travel beyond either limit, making reversal immediate.
    return zoomForScale(
        current,
        scale / previousScale,
        sensitivity,
        maximum,
        inverted
    );
}
